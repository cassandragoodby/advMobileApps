package com.example.cassandragoodby.lab7;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class DetailActivity extends Activity implements DrinksDetailFragment.ButtonClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        DrinksDetailFragment drinkDetailFragment = (DrinksDetailFragment) getFragmentManager().findFragmentById(R.id.fragment_container);
        //get the id passed in the intent
        int typeId = (int) getIntent().getExtras().get("id");
        //int universeId = (int) getIntent().getIntExtra("id");
        //pass the universe id to the fragment
        drinkDetailFragment.setType(typeId);
    }

    @Override public void adddrinkclicked(View view){
        DrinksDetailFragment fragment = (DrinksDetailFragment)getFragmentManager().findFragmentById(R.id.fragment_container);
        fragment.adddrink();
    }
}
