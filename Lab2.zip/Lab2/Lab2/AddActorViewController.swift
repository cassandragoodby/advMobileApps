//
//  AddActorViewController.swift
//  Lab2
//
//  Created by Cassandra Goodby on 2/20/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

class AddActorViewController: UIViewController {
    var addedActor = String()
    
    
    
    @IBOutlet weak var actorTextField: UITextField!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "doneSegue"{
            //only add a country if there is text in the textfield
            if ((actorTextField.text?.isEmpty) == false){
                addedActor=actorTextField.text!
            }
        }
    }

    @IBOutlet weak var newActor: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
