//
//  Continents.swift
//  Lab2
//
//  Created by Cassandra Goodby on 2/20/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import Foundation

class Movies {
    var actorData = [String : [String]]()
    var movies = [String]()
}
