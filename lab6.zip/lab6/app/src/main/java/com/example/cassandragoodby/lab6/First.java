package com.example.cassandragoodby.lab6;

/**
 * Created by CassandraGoodby on 4/5/18.
 */

public class First {
    private String name;
    private int imageResourceID;
    //constructor
    private First(String newname, int newID){
        this.name = newname;
        this.imageResourceID = newID;
    }
    public static final First[] ale = {
        new First("White Rascal", R.drawable.whiterascal),
                new First("Raja", R.drawable.raja),
                new First("Maharaja", R.drawable.maharaja),
                new First("Ellies Brown", R.drawable.elliesbrown)
    };

    public static final First[] lager = {
            new First("Joes Pilsner", R.drawable.joespilsner),
            new First("Persik", R.drawable.persik),
            new First("Raspberry Sour", R.drawable.raspberrysour)
    };

    public String getName(){
        return name;
    }

    public int getImageResourceID(){
        return imageResourceID;
    }

    //the string representation of a tulip is its name
    public String toString(){
        return this.name;
    }
}
