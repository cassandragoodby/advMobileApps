package com.example.cassandragoodby.lab6;

import android.app.ListActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SecondMainActivity extends ListActivity {
    private String beertype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.firstactivity_first_main);
        Intent i = getIntent();
        beertype = i.getStringExtra("beertype");
//        ListView listBeer = (ListView)findViewById(R.id.listView);
        ListView listBeer = getListView();
        ArrayAdapter<First> listAdapter;
        switch (beertype){
            case "Ale":
                listAdapter = new ArrayAdapter<First>(this, android.R.layout.simple_list_item_1, First.ale);

                break;
            case "Lager":
                listAdapter = new ArrayAdapter<First>(this, android.R.layout.simple_list_item_1, First.lager);
            break;
            default: listAdapter = new ArrayAdapter<First>(this, android.R.layout.simple_list_item_1, First.lager);
        }

//set the array adapter on the list view
        listBeer.setAdapter(listAdapter);
    }

    @Override
    public void onListItemClick(ListView listView, View view, int position, long id){
        Intent intent = new Intent(SecondMainActivity.this, BeerActivity.class);
        intent.putExtra("beerid", (int) id);
        intent.putExtra("beertype", beertype);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.create_order:
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.averybrewing.com/"));
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
