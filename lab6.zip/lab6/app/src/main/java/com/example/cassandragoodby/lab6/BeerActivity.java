package com.example.cassandragoodby.lab6;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class BeerActivity extends Activity {
    private String beertype;
//    private String breedname;
//    private String groupname;
//    private int breedindex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beer);
        Intent i = getIntent();
        beertype = i.getStringExtra("beertype");
//        beername = i.getStringExtra("beerName");
//        breedindex = (Integer)i.getExtras().get("breedindex");

        ImageView beerImage = (ImageView)findViewById(R.id.beerImageView);
        TextView beerName = (TextView)findViewById(R.id.beer_name);

        int beernum = (Integer)getIntent().getExtras().get("beerid");

        switch (beertype){
            case "Ale":
                First beerale = First.ale[beernum];
                beerImage.setImageResource(First.ale[beernum].getImageResourceID());
                beerName.setText(beerale.getName());
                break;
            case "Lager":
                First beerlager = First.lager[beernum];
                beerImage.setImageResource(First.lager[beernum].getImageResourceID());
                beerName.setText(beerlager.getName());
                break;
            default:
                First beer = First.ale[beernum];
                beerImage.setImageResource(First.ale[beernum].getImageResourceID());
                beerName.setText(beer.getName());
        }
//        First beer = First.ale[beernum];
//        beerImage.setImageResource(beer.getImageResourceID());
//        beerName.setText(beer.getName());

        ActionBar actionBar = getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.create_order:
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.averybrewing.com/"));
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
