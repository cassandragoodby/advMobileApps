//
//  restaurant.swift
//  Midterm1
//
//  Created by Cassandra Goodby on 3/15/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import Foundation


class Restaurant {
    var RestaurantName = [String]()
    var urls = [String]()
}

struct restaurant: Decodable{
    let title: String
    let url : String
}
