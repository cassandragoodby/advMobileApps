//
//  TableViewController.swift
//  Midterm1
//
//  Created by Cassandra Goodby on 3/15/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

var restauranteNames = [String: [String]]()
var name = [String]()
var url = [String]()

class TableViewController: UITableViewController {
    var restList = [restaurant]()
    var searchController : UISearchController!
    var myDict: NSDictionary?
    
    
    override func viewDidLoad() {
        if let pathURL = Bundle.main.url(forResource: "restaurants", withExtension: "plist"){
            let plistdecoder = PropertyListDecoder()
            do {
                let data = try Data(contentsOf: pathURL)
                restauranteNames = try plistdecoder.decode([String: [String]].self, from: data)
                let namearray = Array(restauranteNames.keys)
                let urlarray = Array(arrayLiteral: "https://www.backcountrypizzaandtaphouse.com/","https://www.luciles.com/","https://www.thewestendtavern.com/","https://www.rinconargentinoboulder.com/")
                var index = 0
                for names in namearray{
                    name = [namearray[index]]
//                    print(restauranteNames.keys)
                    url = [urlarray[index]]
                  print(name)
                    print(url)
                    print("URL")
                    index = index + 1
                    print(index)
                }
            } catch {
                // handle error
                print(error)
            }
            print(name)
        }
        
        
        navigationController?.navigationBar.prefersLargeTitles = true
        //search results
        let resultsController = SearchResultsController() //create an instance of our SearchResultsController class
        resultsController.allwords = name //set the allwords property to our words array
        searchController = UISearchController(searchResultsController: resultsController) //initialize our search controller with the resultsController when it has search results to display
        //search bar configuration
        searchController.searchBar.placeholder = "Enter a search term"
        //place holder text
        searchController.searchBar.sizeToFit() //sets appropriate size for the search bar
        tableView.tableHeaderView=searchController.searchBar //install the search bar as the table header
        searchController.searchResultsUpdater = resultsController //sets the instance to update search results
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//         self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    func loadjson(){
        let urlPath = "https://creative.colorado.edu/~apierce/samples/data/restaurants.json"
        guard let url = URL(string: urlPath)
            else {
                print("url error")
                return
        }
        
        let session = URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
            let httpResponse = response as! HTTPURLResponse
            let statusCode = httpResponse.statusCode
            guard statusCode == 200
                else {
                    print("file download error")
                    return
            }
            //download successful
            print("download complete")
            DispatchQueue.main.async {self.parsejson(data!)}
        })
        //must call resume to run session
        session.resume()
    }
    
    
    func parsejson(_ data: Data){
        print(data)
    
        tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return name.count
    }
    
    // Displays table view cells
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //dequeues an existing cell if one is available, or creates a new one and adds it to the table
        let cell = tableView.dequeueReusableCell(withIdentifier:
            "Cell", for: indexPath)
        cell.textLabel?.text = name[indexPath.row]
//        cell.textLabel?.text = "wow"
        return cell
    }


    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    
//     Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
//         Return false if you do not want the specified item to be editable.
        return true
    }
 

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
//            //Delete the country from the array
            name.remove(at: indexPath.row)
//            let chosenWord = continentListDetail.continents[selectedContinent]
//            //Delete from the data model instance
//            continentListDetail.continentData[chosenContinent]?.remove(at:
//                indexPath.row)
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            print("wow")
            if let indexPath = self.tableView.indexPathForSelectedRow {
                print("wow2")
//                let resting = restList[indexPath.row]
                let title = name[indexPath.row]
                let urlsend = url[indexPath.row]
                print(urlsend)
                print("wow3")
//                print(resting)
                let controller = (segue.destination as! DetailViewController)
//                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = urlsend
                controller.title = title
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }
}
