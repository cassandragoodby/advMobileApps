//
//  overviewViewController.swift
//  timerProject
//
//  Created by Cassandra Goodby on 3/12/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit
var workoutNumber = 0
var timeWorkout = 0
var resting = 0
var reps = 0
var minutes = 0
var seconds = 0
var time = 0
var fulltime = ""
var thetimemin = ""
var thetimesec = ""

class overviewViewController: UIViewController {
    @IBOutlet weak var workoutnum: UILabel!
    
    @IBOutlet weak var timeper: UITextField!
    @IBOutlet weak var resttime: UITextField!
    @IBOutlet weak var repsAmount: UITextField!
    @IBOutlet weak var totalTime: UILabel!
   
    @IBAction func nextSegBtn(_ sender: Any) {
        workoutNumber = Int(workoutnum.text!)!
        timeWorkout = Int(timeper.text!)!
        resting = Int(resttime.text!)!
        reps = Int(repsAmount.text!)!
    }
    @IBOutlet weak var startBtn: UIButton!
    @IBAction func timeUpdateTot(_ sender: Any) {

        if(timeper.text != "" && resttime.text != "" && repsAmount.text != "" ){
            startBtn.isEnabled = true
             workoutNumber = Int(workoutnum.text!)!
             timeWorkout = Int(timeper.text!)!
             resting = Int(resttime.text!)!
             reps = Int(repsAmount.text!)!
            let totalworkoutTime = workoutNumber*timeWorkout
            let restingTime = workoutNumber*resting
             time = ((totalworkoutTime+restingTime)*reps)-resting
             minutes = time/60
             seconds = time - (minutes*60)
            thetimemin = String(minutes)
            thetimesec = String(seconds)
            if thetimesec.count == 1{
                thetimesec = "0"+thetimesec
            }
            if thetimemin.count == 1{
                thetimemin = "0"+thetimemin
            }
            fulltime = thetimemin + ":" + thetimesec
            totalTime.text = fulltime
            
        }
    }
    @IBAction func restingUpdateTot(_ sender: Any) {
        
        if(timeper.text != "" && resttime.text != "" && repsAmount.text != "" ){
            startBtn.isEnabled = true
            workoutNumber = Int(workoutnum.text!)!
            let timeWorkout = Int(timeper.text!)!
            let resting = Int(resttime.text!)!
            let reps = Int(repsAmount.text!)!
            let totalworkoutTime = workoutNumber*timeWorkout
            let restingTime = workoutNumber*resting
            let time = ((totalworkoutTime+restingTime)*reps)-resting
            minutes = time/60
            seconds = time - (minutes*60)
            var thetimemin = String(minutes)
            var thetimesec = String(seconds)
            if thetimesec.count == 1{
                thetimesec = "0"+thetimesec
            }
            if thetimemin.count == 1{
                thetimemin = "0"+thetimemin
            }
            fulltime = thetimemin + ":" + thetimesec
            totalTime.text = fulltime
        }
    }
    
    @IBAction func printTime(_ sender: Any) {
    
        if(timeper.text != "" && resttime.text != "" && repsAmount.text != "" ){
            startBtn.isEnabled = true
            workoutNumber = Int(workoutnum.text!)!
            let timeWorkout = Int(timeper.text!)!
            let resting = Int(resttime.text!)!
            let reps = Int(repsAmount.text!)!
            let totalworkoutTime = workoutNumber*timeWorkout
            let restingTime = workoutNumber*resting
            let time = ((totalworkoutTime+restingTime)*reps)-resting
            minutes = time/60
             seconds = time - (minutes*60)
            var thetimemin = String(minutes)
            var thetimesec = String(seconds)
            if thetimesec.count == 1{
                thetimesec = "0"+thetimesec
            }
            if thetimemin.count == 1{
                thetimemin = "0"+thetimemin
            }
            fulltime = thetimemin + ":" + thetimesec
            totalTime.text = fulltime
        }
    }
    override func viewDidLoad() {
        //#6381a3 99,129,163  //444444
        let blueColor = UIColor(red: 99/255.0, green: 129/255.0, blue: 163/255.0, alpha: 1.0)
        view.backgroundColor = blueColor
        //        let darkblueColor = UIColor(red: 0/255.0, green: 0/255.0, blue: 26/255.0, alpha: 1.0)
        //        var navigationBarAppearace = UINavigationBar.appearance()
        navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.tintColor = UIColor.white
        navigationController?.navigationBar.barTintColor = UIColor.white
        // change navigation item title color
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.barTintColor = blueColor
//        self.tableView.backgroundColor = blueColor
        startBtn.isEnabled = false
        print(list.count)
        workoutnum.text = String(list.count)
         super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let blueColor = UIColor(red: 99/255.0, green: 129/255.0, blue: 163/255.0, alpha: 1.0)
        view.backgroundColor = blueColor
        navigationController?.navigationBar.barTintColor = blueColor
        let slate = UIColor(red: 0/255.0, green: 0/255.0, blue: 26/255.0, alpha: 1.0)
        startBtn.setTitleColor(UIColor.white, for: .normal)
        startBtn.setTitleColor(UIColor.gray, for: .disabled)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
