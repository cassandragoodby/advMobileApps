//
//  FirstViewController.swift
//  timerProject
//
//  Created by Cassandra Goodby on 3/11/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

//var list = ["bicycle crunches", "v ups", "star crunches"]
var list = [String]()

class FirstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var hideBtn: UIButton!
    @IBAction func nextHide(_ sender: Any) {
        
    }
    @IBOutlet weak var tableView: UITableView!
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return (list.count)
    }

    

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let blueColor = UIColor(red: 99/255.0, green: 129/255.0, blue: 163/255.0, alpha: 1.0)
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "cell")
        cell.textLabel?.text = list[indexPath.row]
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
//        cell.contentView.alpha = 0.5;
        cell.backgroundColor = blueColor
        cell.textLabel?.textColor = UIColor.white
        tableView.backgroundColor = blueColor
        hideBtn.setTitleColor(UIColor.white, for: .normal)
        hideBtn.setTitleColor(UIColor.gray, for: .disabled)
        cell.textLabel?.font = UIFont(name: "Avenir", size:22)
//        self.contentInsetAdjustmentBehavior = false
        tableView.contentInset = UIEdgeInsets.zero
        self.tableView.separatorStyle = .none
        return (cell)
    }
    
    public func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath){
        if editingStyle == UITableViewCell.EditingStyle.delete{
            list.remove(at: indexPath.row)
            tableView.reloadData()
        }
        if(tableView.visibleCells.isEmpty){
            hideBtn.isEnabled = false
        
        }
        else{
            hideBtn.isEnabled = true
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //#6381a3 99,129,163  //444444
        let blueColor = UIColor(red: 99/255.0, green: 129/255.0, blue: 163/255.0, alpha: 1.0)
        view.backgroundColor = blueColor
//        let darkblueColor = UIColor(red: 0/255.0, green: 0/255.0, blue: 26/255.0, alpha: 1.0)
//        var navigationBarAppearace = UINavigationBar.appearance()
        navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.tintColor = UIColor.white
        navigationController?.navigationBar.barTintColor = UIColor.white
        // change navigation item title color
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.barTintColor = blueColor
        self.tableView.backgroundColor = blueColor
        tableView.contentInset = UIEdgeInsets.zero
        self.tableView.separatorStyle = .none
        let backButton = UIBarButtonItem(title: "", style: .plain, target: navigationController, action: nil)
        navigationItem.leftBarButtonItem = backButton
        tableView.reloadData()
        if(tableView.visibleCells.isEmpty){
            hideBtn.isEnabled = false
        }
        else{
            hideBtn.isEnabled = true
        }
    }

    
    override func viewDidLoad() {
        
        navigationController?.navigationBar.prefersLargeTitles = true
        let backButton = UIBarButtonItem(title: "", style: .plain, target: navigationController, action: nil)
        navigationItem.leftBarButtonItem = backButton
        if(tableView.visibleCells.isEmpty){
            hideBtn.isEnabled = false
        }
        else{
            hideBtn.isEnabled = true
        }
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

