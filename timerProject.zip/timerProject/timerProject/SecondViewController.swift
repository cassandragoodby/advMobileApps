//
//  SecondViewController.swift
//  timerProject
//
//  Created by Cassandra Goodby on 3/11/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    let stringTime = fulltime
    var workoutTime = String(timeWorkout)
    var restTime = String(resting)
    var click = 0
    var workoutLoop = list.count
    var workoutLoopCount = 0
    
    var countTime = timeWorkout
    var restNowTime = resting
    var playbool = true
    var repsNum = reps
    var totalsecond = seconds
    var totalMinutes = minutes

    @IBOutlet weak var resetLabel: UIButton!
    
    @IBOutlet weak var upcomingLabel: UILabel!
    @IBOutlet weak var backButton: UINavigationItem!
    
    @IBAction func resetButton(_ sender: Any) {
        totalsecond = seconds
        totalMinutes = minutes
        var totalsecondprint = String(totalsecond)
        var totalminprint = String(totalMinutes)
        if(totalsecondprint.count == 1){
            totalsecondprint = "0"+totalsecondprint
        }
        if(totalminprint.count == 1){
            totalminprint = "0"+totalminprint
        }
        timer.text = totalminprint+":"+totalsecondprint
//        timer.text = fulltime
        playLabel.isEnabled = true
        upcomingLabel.text = ""
        resetLabel.isEnabled = false
        realTimer.invalidate()
        restTimer.invalidate()
        countTime = timeWorkout
        print(countTime)
        playLabel.setTitle("Play", for: .normal)
        isPaused = true
        playbool = true
        restNowTime = resting
        print(restNowTime)
        workoutLoopCount = 0
        topLabel.text = list[0]
        if(workoutTime != ""){
            let workoutTimeint = Int(timeWorkout)
            if workoutTimeint >= 60{
                let minutes = timeWorkout/60
                let seconds = timeWorkout - (minutes*60)
                let thetimemin = String(minutes)
                var thetimesec = String(seconds)
                if thetimesec.count == 1{
                    thetimesec = "0"+thetimesec
                }
                workoutTime = thetimemin + ":" + thetimesec
            }
            if workoutTime.count == 1{
                workoutTime = "00:0" + workoutTime
            }
            if workoutTime.count == 2{
                workoutTime = "00:" + workoutTime
            }
            secondsLabel.text =  workoutTime
        }
    }
    @IBOutlet weak var topLabel: UILabel!
    @IBOutlet weak var timer: UILabel!
    @IBOutlet weak var playLabel: UIButton!
    var isPaused = true
    @IBAction func playButton(_ sender: Any) {
        resetLabel.isEnabled = true
        if isPaused{
            if playbool{
                playLabel.setTitle("Pause", for: .normal)
                realTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(SecondViewController.counter), userInfo: nil, repeats: true)
            }
            else{
                playLabel.setTitle("Pause", for: .normal)
                restTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(SecondViewController.restCount), userInfo: nil, repeats: true)
                
            }
            isPaused = false
        } else {
            playLabel.setTitle("Play", for: .normal)
            realTimer.invalidate()
            restTimer.invalidate()
            isPaused = true
        }
    }
    
    @IBOutlet weak var secondsLabel: UILabel!
    
    @IBAction func doneBtn(_ sender: Any) {
        realTimer.invalidate()
        countTime = timeWorkout
        list = [String]()
    }
    
    var time = 0
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        topLabel.text = list[0]
        timer.text = fulltime
        resetLabel.setTitleColor(UIColor.white, for: .normal)
        resetLabel.setTitleColor(UIColor.gray, for: .disabled)
        if(workoutTime != ""){
            let workoutTimeint = Int(timeWorkout)
            if workoutTimeint >= 60{
                let minutes = timeWorkout/60
                let seconds = timeWorkout - (minutes*60)
                let thetimemin = String(minutes)
                var thetimesec = String(seconds)
                if thetimesec.count == 1{
                    thetimesec = "0"+thetimesec
                }
                workoutTime = thetimemin + ":" + thetimesec
            }
            if workoutTime.count == 1{
                workoutTime = "00:0" + workoutTime
            }
            if workoutTime.count == 2{
                workoutTime = "00:" + workoutTime
            }
            secondsLabel.text =  workoutTime
        }
    }
    
    override func viewDidLoad() {
        let pinkColor = UIColor(red: 195/255.0, green: 108/255.0, blue: 131/255.0, alpha: 1.0)
        view.backgroundColor = pinkColor
        navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.tintColor = UIColor.white
        navigationController?.navigationBar.barTintColor = UIColor.white
        // change navigation item title color
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.barTintColor = pinkColor
//        let 195,108,131
        workoutTime = String(timeWorkout)
        restTime = String(resting)
        topLabel.text = list[0]
        timer.text = fulltime
        if workoutTime.count == 1{
            workoutTime = "00:0" + workoutTime
        }
        if workoutTime.count == 2{
            workoutTime = "00:" + workoutTime
        }
        secondsLabel.text =  workoutTime
        resetLabel.isEnabled = false
//        let tapGestureRecognizer = UITapGestureRecognizer(target:self, action: #selector(SecondViewController.somethingWasTapped(_:)))
//        self.navigationController?.navigationBar.addGestureRecognizer(tapGestureRecognizer)
        super.viewDidLoad()
    }
    
    @objc func somethingWasTapped(_ sth: AnyObject){
        print("Hey there")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        realTimer.invalidate()
        restTimer.invalidate()
    }
    
    var realTimer = Timer()
    var restTimer = Timer()
    
    @objc func theTimer(){
        playbool = true
        if(workoutLoopCount < workoutLoop){
            countTime = timeWorkout
//            countTime = countTime + 1
//            secondsLabel.text =  String(countTime)
            realTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(SecondViewController.counter), userInfo: nil, repeats: true)
        }
    }
    
    @objc func counter(){
        topLabel.text = list[workoutLoopCount]
//        var toptime = Int(time)
        print(totalsecond)
        if(totalsecond == 0){
            totalMinutes -= 1
            totalsecond = 60
        }
        totalsecond-=1
        print(totalsecond)
        var totalsecondprint = String(totalsecond)
        var totalminprint = String(totalMinutes)
        if(totalsecondprint.count == 1){
            totalsecondprint = "0"+totalsecondprint
        }
        if(totalminprint.count == 1){
            totalminprint = "0"+totalminprint
        }
        timer.text = totalminprint+":"+totalsecondprint
        countTime -= 1
        let minutes = countTime/60
//        print(minutes)
        let seconds = countTime - (minutes*60)
//        print(seconds)
        var thetimemin = String(minutes)
//        print(thetimemin)
        var thetimesec = String(seconds)
//        print(thetimesec)
        if thetimesec.count == 1{
            thetimesec = "0"+thetimesec
        }
        if thetimemin.count == 1{
            thetimemin = "0"+thetimemin
        }
        fulltime = thetimemin + ":" + thetimesec
        secondsLabel.text =  String(fulltime)
        upcomingLabel.text = ""
//        print("Count time")
//        print(countTime)
//        print("Full time")
//        print(fulltime)
        if(countTime == 0){
            click = 0
            workoutLoopCount = workoutLoopCount+1
            realTimer.invalidate()
            if(workoutLoopCount == workoutLoop){
                if (repsNum > 1){
                    repsNum = repsNum-1
                    restTimer.invalidate()
                    realTimer.invalidate()
                    workoutLoopCount = 0
                    restNowTime = resting
                    theRestTimer()
                }
                else{
                    workoutLoopCount = 0
                    restTimer.invalidate()
                    realTimer.invalidate()
                    topLabel.text = "DONE"
                    playLabel.isEnabled = false
                }
            }
            else{
                theRestTimer()
            }
            countTime = 0
        }
    }
    
    @objc func theRestTimer(){
        playbool = false
//        restNowTime = restNowTime + 1
        restTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(SecondViewController.restCount), userInfo: nil, repeats: true)
        
    }
    
    @objc func restCount(){
        topLabel.text = "Rest"
        upcomingLabel.text = "Get ready for: "+list[workoutLoopCount]
        print(totalsecond)
        if(totalsecond == 0){
            totalMinutes -= 1
            totalsecond = 60
        }
        totalsecond-=1
        print(totalsecond)
        var totalsecondprint = String(totalsecond)
        var totalminprint = String(totalMinutes)
        if(totalsecondprint.count == 1){
            totalsecondprint = "0"+totalsecondprint
        }
        if(totalminprint.count == 1){
            totalminprint = "0"+totalminprint
        }
        timer.text = totalminprint+":"+totalsecondprint
        restNowTime -= 1
        let minutes = restNowTime/60
        let seconds = restNowTime - (minutes*60)
        var thetimemin = String(minutes)
        var thetimesec = String(seconds)
        if thetimesec.count == 1{
            thetimesec = "0"+thetimesec
        }
        if thetimemin.count == 1{
            thetimemin = "0"+thetimemin
        }
        fulltime = thetimemin + ":" + thetimesec
        secondsLabel.text =  String(fulltime)
        
        if(restNowTime == 0){
            
            restNowTime = resting
            restTimer.invalidate()
            if (workoutLoopCount == list.count){
                workoutLoopCount = 0
                restTimer.invalidate()
                realTimer.invalidate()
            }
            else{
                theTimer()
            }
            
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}

