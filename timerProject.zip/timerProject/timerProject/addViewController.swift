//
//  addViewController.swift
//  timerProject
//
//  Created by Cassandra Goodby on 3/12/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

var selectedArray = [String]()

class addViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   

    var tableData = [String]()
    var selected: Bool!
    
    @IBOutlet weak var workouttableView: UITableView!
    
    @IBOutlet weak var insertCustom: UITextField!
    

    @IBAction func addCustom(_ sender: Any) {
        if(insertCustom.text != ""){
            tableData.append(insertCustom.text!)
            insertCustom.text = ""
        }
        workouttableView.reloadData()
    }

    @IBAction func addItemstomain(_ sender: Any) {
        if(selectedArray.count != 0){
            list.append(selectedArray[0])
            selectedArray = [String]()
            self.dismiss(animated: true, completion: nil)
        }
        else{
            self.dismiss(animated: true, completion: nil)
        }
    }

    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            selectedArray = [String]()
            tableView.cellForRow(at: indexPath)?.accessoryType = UITableViewCell.AccessoryType.checkmark
            let selectedCell = tableView.cellForRow(at: indexPath)
        
            selectedArray.append(selectedCell!.textLabel!.text!)
            print(selectedCell!.textLabel!.text!)
        print(selectedArray)
        
    }
    
    public func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        selectedArray = [String]()
        tableView.cellForRow(at: indexPath)?.accessoryType = UITableViewCell.AccessoryType.none
    }


    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return (tableData.count)
    }
    
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        tableView.contentInset = UIEdgeInsets.zero
        tableView.separatorStyle = .none
        let blueColor = UIColor(red: 99/255.0, green: 129/255.0, blue: 163/255.0, alpha: 1.0)
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "cell")
        cell.textLabel?.text = tableData[indexPath.row]
        cell.backgroundColor = blueColor
        cell.textLabel?.textColor = UIColor.white
        tableView.backgroundColor = blueColor
        cell.textLabel?.font = UIFont(name: "Avenir", size:22)
        tableView.flashScrollIndicators()  
        return (cell)
    }
    
    public func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath){
        if editingStyle == UITableViewCell.EditingStyle.delete{
            tableData.remove(at: indexPath.row)
            workouttableView.reloadData()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let blueColor = UIColor(red: 99/255.0, green: 129/255.0, blue: 163/255.0, alpha: 1.0)
//        self.tableView.backgroundColor = blueColor
        
    }

    override func viewDidLoad() {
        //#6381a3 99,129,163  //444444
        let blueColor = UIColor(red: 99/255.0, green: 129/255.0, blue: 163/255.0, alpha: 1.0)
        view.backgroundColor = blueColor
        
        //        let darkblueColor = UIColor(red: 0/255.0, green: 0/255.0, blue: 26/255.0, alpha: 1.0)
        //        var navigationBarAppearace = UINavigationBar.appearance()
        navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.tintColor = UIColor.white
        navigationController?.navigationBar.barTintColor = UIColor.white
        // change navigation item title color
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.barTintColor = blueColor
        self.workouttableView.delegate = self
        self.workouttableView.dataSource = self
        let path = Bundle.main.path(forResource: "workouts", ofType: "plist")
        let dict = NSDictionary(contentsOfFile: path!)
        tableData = dict!.object(forKey: "workouts") as! [String]
    
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
