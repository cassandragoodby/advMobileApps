//
//  CollectionSupplementaryView.swift
//  lab3v3
//
//  Created by Cassandra Goodby on 3/3/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

class CollectionSupplementaryView: UICollectionReusableView {
        
    @IBOutlet weak var headerLabel: UILabel!
}
