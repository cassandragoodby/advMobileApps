package com.example.cassandragoodby.project2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class timer extends Activity {

    private long Start_time_in_millistot = 60000;
    private long repsTimeinMillis = 60000;
    private long restTimeinMillis = 60000;

    private CountDownTimer totcountdowntimer;
    private CountDownTimer repscountdowntimer;
    private CountDownTimer restcountdowntimer;

    private TextView totTextview;
    private TextView timerTextview;
    private TextView infoTextview;
    private Button startButton;
    private Button restartButton;

    private boolean tottimerrunning;
    private boolean timerrunning;
    private boolean repsrunning;
    private boolean restrunning;

    private long tottimeleftinmillis;
    private long repstimeleftinmillis;
    private long resttimeleftinmillis;

    private int repsTot;
    private int repsLoop;
    private int forloop=0;
    private int workoutsTot;
    private boolean restwasrunning;
    private boolean repswasrunning;
    private ArrayList<String> workoutslist = new ArrayList<String>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);
        Intent intent = getIntent();
        Bundle extras = getIntent().getExtras();
        int totalTime = intent.getIntExtra("total", 0);
        int repsTime = intent.getIntExtra("time", 0);
        final int restTime = intent.getIntExtra("rest", 0);
        int repsTotint = intent.getIntExtra("rep", 0);
        repsTot = repsTotint;
        TextView timeshowing = (TextView) findViewById(R.id.textView3);
        int minutes = intent.getIntExtra("minutes", 0);
        int seconds = intent.getIntExtra("seconds", 0);
        final int workoutnum = intent.getIntExtra("workoutnum",0);
        workoutslist = intent.getStringArrayListExtra("workouts");
        workoutsTot = workoutnum;
        String timetoshow = "";
        minutes = totalTime / 60;
        seconds = totalTime - (minutes * 60);
        if (totalTime >= 60) {
            String thetimemin = Integer.toString(minutes);
            String thetimesec = Integer.toString(seconds);
            if (thetimesec.length() == 1) {
                thetimesec = "0" + thetimesec;
            }
            timetoshow = thetimemin + ":" + thetimesec;
        }
        else{
            seconds = totalTime;
            String thetimesec = Integer.toString(seconds);
            String secondstext = Integer.toString(seconds);
            if(secondstext.length()==1){
                timetoshow = "00:0" + thetimesec;
            }
            else {
                timetoshow = "00:" + thetimesec;
            }
        }

        timeshowing.setText(timetoshow);


        long totalTimestart = totalTime*1000;
        Start_time_in_millistot = totalTimestart;
        tottimeleftinmillis = Start_time_in_millistot;
        long repsTimestart = repsTime*1000;
        repsTimeinMillis = repsTimestart;
        repstimeleftinmillis = repsTimeinMillis;
        long restTimestart = restTime*1000;
        restTimeinMillis = restTimestart;
        resttimeleftinmillis = restTimeinMillis;
        totTextview = findViewById(R.id.textView3);
        timerTextview = findViewById(R.id.textView5);
        infoTextview = findViewById(R.id.textView4);
        startButton = findViewById(R.id.button2);
        restartButton = findViewById(R.id.button3);
        repsrunning = false;
        restrunning = false;
        tottimerrunning =false;

//        timerTextview.setText(repsTime);
        updateCountdownTextreps();
        infoTextview.setText(workoutslist.get(forloop));

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tottimerrunning){
                    pauseTimer();
                }
                else{
                    startTimer();
                    if(restwasrunning) {
                        restStart();
                    }
                    else{
                        repsStart();
                    }
                }
            }
        });

        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });

        updateCountdownTexttot();
    }
    public void done(View view){
        Intent intent = new Intent(timer.this, MainActivity.class);
        startActivity(intent);
    }

    private void startTimer(){
//        Toast.makeText(this, "Started"+workoutslist, Toast.LENGTH_LONG).show();
            totcountdowntimer = new CountDownTimer(tottimeleftinmillis, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    tottimeleftinmillis = millisUntilFinished;
                    updateCountdownTexttot();
                }

                @Override
                public void onFinish() {
                    tottimerrunning = false;
                    startButton.setText("Play");
                    startButton.setVisibility(View.INVISIBLE);
                }
            }.start();
            updateCountdownTexttot();
            tottimerrunning = true;
            startButton.setText("Pause");
    }

    private void repsStart(){
        if(forloop<workoutsTot) {
            repscountdowntimer = new CountDownTimer(repstimeleftinmillis, 1000) {
                @Override
                public void onTick(long repsTimeuntilFin) {
                    repstimeleftinmillis = repsTimeuntilFin;
                    updateCountdownTextreps();
                }

                @Override
                public void onFinish() {
                    repstimeleftinmillis = repsTimeinMillis;
                    forloop++;
                    repsrunning = false;
                    restwasrunning = false;
                    restStart();
                }
            }.start();
//            updateCountdownTextreps();
            infoTextview.setText(workoutslist.get(forloop));
            timerrunning = true;
            repsrunning = true;
        }
    }

    private void restStart(){
        if(forloop==workoutsTot && repsTot>1){
            forloop=0;
            repsTot=repsTot-1;
        }
        if(forloop<workoutsTot) {
            restcountdowntimer = new CountDownTimer(resttimeleftinmillis, 1000) {
                @Override
                public void onTick(long restTimeuntilFin) {
                    resttimeleftinmillis = restTimeuntilFin;
                    updateCountdownTextrest();
                }

                @Override
                public void onFinish() {
                    resttimeleftinmillis = restTimeinMillis;
                    repswasrunning = false;
                    restrunning = false;
                    repsStart();
                }
            }.start();
//            updateCountdownTextrest();
            infoTextview.setText("Get ready for: "+workoutslist.get(forloop));
            timerrunning = true;
            restrunning = true;
        }
        else{
            infoTextview.setText("Done!");
        }
    }

    private void pauseTimer(){
        totcountdowntimer.cancel();
        if(restrunning) {
            restcountdowntimer.cancel();
            restwasrunning = true;
        }
        if(repsrunning) {
            repscountdowntimer.cancel();
            repswasrunning = true;
        }
        tottimerrunning=false;
        timerrunning = false;
        repsrunning = false;
        restrunning = false;
        startButton.setText("Play");
    }

    private void resetTimer(){
        forloop=0;
        startButton.setVisibility(View.VISIBLE);
        tottimeleftinmillis = Start_time_in_millistot;
        repstimeleftinmillis = repsTimeinMillis;
        resttimeleftinmillis = restTimeinMillis;
        totcountdowntimer.cancel();
        if(restrunning) {
            restcountdowntimer.cancel();
        }

        if(repsrunning) {
            repscountdowntimer.cancel();
        }
        tottimerrunning=false;
        timerrunning = false;
        repsrunning = false;
        restrunning = false;
        startButton.setText("Play");
        infoTextview.setText(workoutslist.get(forloop));
        updateCountdownTexttot();
        updateCountdownTextreps();
    }

    private void updateCountdownTexttot(){
        int minutes = (int) (tottimeleftinmillis /1000)/60;
        int seconds = (int) (tottimeleftinmillis/1000) %60;

        String timerLeftFormatted = String.format(Locale.getDefault(),"%02d:%02d",minutes,seconds);
        totTextview.setText(timerLeftFormatted);
    }

    private void updateCountdownTextreps(){
        int minutes2 = (int) (repstimeleftinmillis /1000)/60;
        int seconds2 = (int) (repstimeleftinmillis/1000) %60;

        String timerLeftFormatted2 = String.format(Locale.getDefault(),"%02d:%02d",minutes2,seconds2);
        timerTextview.setText(timerLeftFormatted2);
    }

    private void updateCountdownTextrest(){
        int minutes3 = (int) (resttimeleftinmillis /1000)/60;
        int seconds3 = (int) (resttimeleftinmillis/1000) %60;

        String timerLeftFormatted3 = String.format(Locale.getDefault(),"%02d:%02d",minutes3,seconds3);
        timerTextview.setText(timerLeftFormatted3);
    }

}
