package com.example.cassandragoodby.project2;

/**
 * Created by CassandraGoodby on 5/5/18.
 */

public class workouts {
    private String name;

    //constructor
    private workouts(String newname){
        this.name = newname;
    }

    public static final workouts[] all = {
            new workouts("V Ups"),
            new workouts("Sit ups"),
            new workouts("Plank"),
            new workouts("Russian Twist"),
            new workouts("Dead Bug")
    };

    public String getName(){
        return name;
    }

    public String toString(){
        return this.name;
    }
}
