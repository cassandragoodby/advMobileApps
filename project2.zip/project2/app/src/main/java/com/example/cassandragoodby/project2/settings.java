package com.example.cassandragoodby.project2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class settings extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        TextView workoutNum = (TextView) findViewById(R.id.workoutshow);
        Intent intent = getIntent();
        Bundle extras = getIntent().getExtras();
        if(extras != null) {
            ArrayList<String> workouts = extras.getStringArrayList("workout");
//            Toast.makeText(this, "look" + workouts, Toast.LENGTH_LONG).show();
            String workoutNumber = Integer.toString(workouts.size());
            workoutNum.setText(workoutNumber); //amount of workouts
        }

    }

    public void clicking(View view){
        Bundle extras = getIntent().getExtras();
        ArrayList<String> workouts = extras.getStringArrayList("workout");
        EditText timeper = (EditText) findViewById(R.id.timeper);
        EditText resttime = (EditText) findViewById(R.id.resttime);
        EditText repsamt = (EditText) findViewById(R.id.repsamt);
        String timepertxt = timeper.getText().toString();
        String resttimestxt = resttime.getText().toString();
        String repsamttxt = repsamt.getText().toString();
        TextView timeshowing = (TextView) findViewById(R.id.timeshow);
        int totalTime;
        int seconds;
        int minutes;
        if(TextUtils.isEmpty(timepertxt) || TextUtils.isEmpty(resttimestxt) || TextUtils.isEmpty(repsamttxt)){
            Toast.makeText(this, "Please fill out all info", Toast.LENGTH_LONG).show();
        }

        else {
            int time = Integer.parseInt(timepertxt);
            int rest = Integer.parseInt(resttimestxt);
            int rep = Integer.parseInt(repsamttxt);
            String timetoshow = "";
            //update info
            totalTime = (((workouts.size() * time + ((workouts.size()) * rest))) * rep) - rest;
            minutes = totalTime / 60;
            seconds = totalTime - (minutes * 60);
//            Toast.makeText(this, "updating"+totalTime, Toast.LENGTH_LONG).show();
            if (totalTime >= 60) {
                String thetimemin = Integer.toString(minutes);
                String thetimesec = Integer.toString(seconds);
                if (thetimesec.length() == 1) {
                    thetimesec = "0" + thetimesec;
                }
                timetoshow = thetimemin + ":" + thetimesec;
            }
            else{
                seconds = totalTime;
                String thetimesec = Integer.toString(seconds);
                String secondstext = Integer.toString(seconds);
                if(secondstext.length()==1){
                    timetoshow = "00:0" + thetimesec;
                }
                else {
                    timetoshow = "00:" + thetimesec;
                }
            }

            timeshowing.setText(timetoshow);
        }
    }

    public void onNextClick(View view){
        EditText timeper = (EditText) findViewById(R.id.timeper);
        EditText resttime = (EditText) findViewById(R.id.resttime);
        EditText repsamt = (EditText) findViewById(R.id.repsamt);
        String timepertxt = timeper.getText().toString();
        String resttimestxt = resttime.getText().toString();
        String repsamttxt = repsamt.getText().toString();
        if(TextUtils.isEmpty(timepertxt) || TextUtils.isEmpty(resttimestxt) || TextUtils.isEmpty(repsamttxt)){
            Toast.makeText(this, "Please fill out all info", Toast.LENGTH_LONG).show();
        }
        else{
            Bundle extras = getIntent().getExtras();
            ArrayList<String> workouts = extras.getStringArrayList("workout");
            int time = Integer.parseInt(timepertxt);
            int rest = Integer.parseInt(resttimestxt);
            int rep = Integer.parseInt(repsamttxt);
            int totalTime;
            int seconds;
            int minutes;
            totalTime = (((workouts.size() * time + ((workouts.size()) * rest))) * rep) - rest;
            minutes = totalTime / 60;
            seconds = totalTime - (minutes * 60);
            Intent intent = new Intent(settings.this, timer.class);
            intent.putExtra("workouts",workouts);
            intent.putExtra("workoutnum",workouts.size());
            intent.putExtra("total", totalTime);
            intent.putExtra("seconds", seconds);
            intent.putExtra("minutes", minutes);
            intent.putExtra("rep", rep);
            intent.putExtra("rest", rest);
            intent.putExtra("time", time);
            startActivity(intent);
        }
    }
}
