package com.example.cassandragoodby.project2;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.SparseBooleanArray;
import android.view.ContextMenu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;




public class MainActivity extends AppCompatActivity {
    private String name;
    String[] workouts2 = new String[] {
            "V Ups",
            "Sit ups",
            "Plank",
            "Russian Twist",
            "Dead Bug"
    };
    String[] workoutsSelected = new String[] {

    };
    ArrayList<String> workouts_Add = new ArrayList<String>(Arrays.asList(workoutsSelected));
    ArrayList<String> workout_list = new ArrayList<String>(Arrays.asList(workouts2));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView list = (ListView)findViewById(R.id.listView);
//        final ArrayList<String> workout_list = new ArrayList<String>(Arrays.asList(workouts2));
//        List<String> workout_list = new ArrayList<String>(Arrays.asList(workouts2));
//        ArrayAdapter<workouts> listAdapter;
//        listAdapter = new ArrayAdapter<workouts>(this, android.R.layout.simple_list_item_1, workouts.all);
        final ArrayAdapter<String> listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, workout_list);
        list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        list.setAdapter(listAdapter);
        list.setOnItemLongClickListener(new OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int arg2, long arg3) {
                // Can't manage to remove an item here
//                workout_list.remove(arg2);
//                onDataChange();
//                listAdapter.notifyDataSetChanged();
                final int delete = arg2;
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Delete entry");
                alert.setMessage("Are you sure you want to delete?");
                alert.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete
                        workout_list.remove(delete);
                        onDataChange();
//                        listAdapter.notifyDataSetChanged();
                    }
                });
                alert.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // close dialog
                        dialog.cancel();
                    }
                });
                alert.show();
//                Toast.makeText(MainActivity.this, "long"+workout_list, Toast.LENGTH_LONG).show();
                return false;
            }
        });
    }

    public void onButtonClickAdd(View view) {
        EditText workoutToAddtxt = (EditText)findViewById(R.id.edittext);
        String workouttoAdd = workoutToAddtxt.getText().toString();
        if(TextUtils.isEmpty(workouttoAdd)) {
            Toast.makeText(this, "Empty Text: Please add workout", Toast.LENGTH_LONG).show();
            return;
        }
        else {
            workout_list.add(workoutToAddtxt.getText().toString());
//            Toast.makeText(this, "Adding "+ workout_list, Toast.LENGTH_LONG).show();
            workoutToAddtxt.setText("");
            onDataChange();
        }
    }

    public void onDataChange(){
        ListView list = (ListView)findViewById(R.id.listView);
         ArrayAdapter<String> listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, workout_list);
        list.setAdapter(listAdapter);
    }

    @Override public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, view, menuInfo);
        ArrayAdapter<String> listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, workout_list);
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        String workoutname = listAdapter.getItem(adapterContextMenuInfo.position);
        menu.setHeaderTitle("Delete " + workoutname);
        menu.add(1, 1, 1, "Yes");
        menu.add(2, 2, 2, "No");
    }

    //On click next get all that are with check marks to workouts selected global variable and go to timer page
    public void nextButtonClicked(View view){
        ListView list = (ListView)findViewById(R.id.listView);
        int cntChoice = list.getCount();
        SparseBooleanArray sparseBooleanArray = list.getCheckedItemPositions();
        //clear
        String[] workoutsSelected = new String[] {};

        ArrayList<String> workouts_Add = new ArrayList<String>(Arrays.asList(workoutsSelected));

        for(int i = 0; i < cntChoice; i++){

            if(sparseBooleanArray.get(i)) {

                workouts_Add.add(list.getItemAtPosition(i).toString());

            }

        }
        if(workouts_Add.isEmpty()) {
            Toast.makeText(this, "Please choose workouts", Toast.LENGTH_LONG).show();
        }
        else{
            Intent intent = new Intent(MainActivity.this, settings.class);
            intent.putExtra("workout", workouts_Add);
            startActivity(intent);

        }
    }



}
