//
//  DataStruct.swift
//  lab4
//
//  Created by Cassandra Goodby on 3/6/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import Foundation

struct DataStruct: Decodable{
    let title: String
    let upCount : Int
    let url : String
}
