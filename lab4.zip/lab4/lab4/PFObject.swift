//
//  PFObject.swift
//  lab4
//
//  Created by Cassandra Goodby on 3/6/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import Foundation
import Parse


class Armor: PFObject, PFSubclassing {
    
    // MARK: - PFSubclassing
    
    override class func initialize() {
        struct Static {
            static var onceToken: dispatch_once_t = 0;
        }
        dispatch_once(&Static.onceToken) {
            self.registerSubclass()
        }
    }
    
    class func parseClassName() -> String {
        return "Armor"
    }
    
    
    // MARK: - Parse Core Properties
    
    @NSManaged var displayName: String?
    
}
