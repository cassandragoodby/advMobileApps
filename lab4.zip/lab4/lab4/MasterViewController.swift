//
//  MasterViewController.swift
//  lab4
//
//  Created by Cassandra Goodby on 3/5/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController {

    var detailViewController: DetailViewController? = nil
    var dataInfo = [DataStruct]()
    var names: [String] = []
    var ups: [String] = []
    var urls: [String] = []
    var parseArray : [Double] = Array() //the array to store the results

    override func viewDidLoad() {
        super.viewDidLoad()
        loadjson()
    }
    
    func loadjson(){
        let urlPath = "https://api.reddit.com/r/Showerthoughts/top/.json?count=20"
        guard let url = URL(string: urlPath)
            else {
                print("url error")
                return
        }
        
        let session = URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
            let httpResponse = response as! HTTPURLResponse
            let statusCode = httpResponse.statusCode
            guard statusCode == 200
                else {
                    print("file download error")
                    return
            }
            //download successful
            print("download complete")
            DispatchQueue.main.async {self.parsejson(data!)}
        })
        //must call resume to run session
        session.resume()
    }
    
    
    func parsejson(_ data: Data){
        print(data)
        do {
            let redditAll = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String : AnyObject]
            if let dataDic = redditAll["data"] as? [String:Any]{
            if let allresults = dataDic["children"] as? [AnyObject]{
            
//                print(allresults)
//                print("lo")
                
                //add results to objects
                for result in allresults {
//                    print(result)
//                    print("here")
                    //check that data exists
                    guard let data = result["data"] as? [String: Any],
                        let newtitle = data["title"] as? String,
                        let newupCount = data["ups"] as? Int,
                        let newurl = data["url"] as? String
                        else {
                            continue
                        }
                    //create new object
//                    print("new object")
                    let newinfo = DataStruct(title: newtitle, upCount: newupCount, url: newurl)
                    self.dataInfo.append(newinfo)
//                    print(newinfo)
                }
                }
            }
            } catch {
            print("Error with JSON: \(error)")
            return
        }
        tableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.clearsSelectionOnViewWillAppear = self.splitViewController!.isCollapsed
        super.viewWillAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Segues
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let information = dataInfo[indexPath.row]
                let title = information.title
                let url = information.url
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = url
                controller.title = title
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }
    
    // MARK: - Table View
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataInfo.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let information = dataInfo[indexPath.row]
        cell.textLabel!.text = information.title
        cell.detailTextLabel!.text = String(information.upCount) + " upvotes"
        
        return cell
    }
    
    /*
     override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     
     override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
     if editingStyle == .Delete {
     objects.removeAtIndex(indexPath.row)
     tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
     } else if editingStyle == .Insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
     }
     }
     */

}

