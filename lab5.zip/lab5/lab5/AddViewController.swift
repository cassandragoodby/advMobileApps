//
//  AddViewController.swift
//  lab5
//
//  Created by Cassandra Goodby on 3/20/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

class AddViewController: UIViewController {
    var addedquote = String()
    var addedauthor = String()
    @IBAction func saveBtn(_ sender: Any) {
    }
    @IBAction func cancelBtn(_ sender: Any) {
    }
    
    @IBOutlet weak var quoteLabel: UILabel!
    @IBOutlet weak var quoteInsert: UITextField!
    
    @IBOutlet weak var authorInput: UITextField!
    @IBOutlet weak var authorLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "savesegue"{
            if quoteLabel.text?.isEmpty == false {
                addedquote = quoteInsert.text!
                addedauthor = authorInput.text!
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
