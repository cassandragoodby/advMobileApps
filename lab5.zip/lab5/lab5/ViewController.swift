//
//  ViewController.swift
//  lab5
//
//  Created by Cassandra Goodby on 3/20/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

