//
//  QuoteTableViewController.swift
//  lab5
//
//  Created by Cassandra Goodby on 3/20/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit
import Firebase

class QuoteTableViewController: UITableViewController {
    var quotes = [Quote]()
    
    var ref: DatabaseReference!
    
    
    @IBAction func unwindSegue(segue:UIStoryboardSegue){
        if segue.identifier == "savesegue" {
            let source = segue.source as! AddViewController
            if source.addedquote.isEmpty == false {
                let newQuote = Quote(quote: source.addedquote, author: source.addedauthor)
                quotes.append(newQuote)
                //create Dictionary
                let newQuoteDict = ["quote": source.addedquote, "author": source.addedauthor]
                let quoteref = ref.child(source.addedquote)
                //write data to Firebase
                quoteref.setValue(newQuoteDict)
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        
        //set up a listener for Firebase data change events
        //this event will fire with the initial data and then all data changes
        ref.observe(DataEventType.value, with: {snapshot in
            self.quotes=[]
            //DataSnapshot represents the Firebase data at a given time
            //loop through all the child data nodes
            for quote in snapshot.children.allObjects as! [DataSnapshot]{
                if let quoteValue = quote.value as? [String: String], //get value as a Dictionary
                    let json = try? JSONEncoder().encode(quoteValue), //encode as JSON
                    let newQuote = try? JSONDecoder().decode(Quote.self, from: json)
                {
                    self.quotes.append(newQuote)
                }
            }
            self.tableView.reloadData()
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(quotes.count)
        print("count")
        print(quotes)
        return quotes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "quotecell", for: indexPath)
        let quote = quotes[indexPath.row]
//        print(quote)
//        print(quote.quote)
        cell.textLabel!.text = quote.quote
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showdetail" {
            let detailVC = segue.destination as! DetailViewController
            let indexPath = tableView.indexPath(for: sender as! UITableViewCell)!
            let quote = quotes[indexPath.row]
            //sets the data for the destination controller
            print("WOW")
            print(quote.quote)
            print(quote.author)
            detailVC.quoteText = quote.quote
            detailVC.authorText = quote.author
        }
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
 

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle:
        UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let quote = quotes[indexPath.row]
            let quoteref = ref.child(quote.quote)
            // Delete the row from Firebase
            quoteref.ref.removeValue()
        }
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
