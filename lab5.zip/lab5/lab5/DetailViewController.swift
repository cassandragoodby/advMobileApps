//
//  DetailViewController.swift
//  lab5
//
//  Created by Cassandra Goodby on 3/20/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    var quoteText : String?
    var authorText : String?
    
    @IBOutlet weak var quoteLabel: UILabel!
    
    @IBOutlet weak var authorLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        quoteLabel.text = quoteText
        authorLabel.text = authorText
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
