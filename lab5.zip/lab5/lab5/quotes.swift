//
//  quotes.swift
//  lab5
//
//  Created by Cassandra Goodby on 3/20/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import Foundation
import Firebase

struct Quote: Codable {
    var quote: String
    var author: String
}
