//
//  ThirdViewController.swift
//  Lab1
//
//  Created by Cassandra Goodby on 2/6/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit
import AVFoundation

class ThirdViewController: UIViewController {
    
    var audioPlayer = AVAudioPlayer()
    
    let path = Bundle.main.path(forResource: "guacSong", ofType: "mp3")
//    let url = URL(fileURLWithPath: path)
//    let url = URL(fileURLWithPath: path)
    var isPlaying = false

    @IBOutlet weak var playBtn: UIButton!
    @IBOutlet weak var pauseBtn: UIButton!
    @IBOutlet weak var resetBtn: UIButton!
    
    @IBAction func playAudio(_ sender: Any) {
        if isPlaying == false{
            audioPlayer.play()
//            button.setTitle("Pause", for: .normal)
            isPlaying = true
        }
    }
    
    @IBAction func pauseAudio(_ sender: Any) {
        if isPlaying == true{
            audioPlayer.pause()
            isPlaying = false
        }
    }
    
    @IBAction func resetAudio(_ sender: Any) {
        if isPlaying == true{
            audioPlayer.pause()
            audioPlayer.currentTime = 0;
            isPlaying = false
        }
        else{
            audioPlayer.currentTime = 0;
            isPlaying = false
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do {
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
        } catch {
            // Error: File not loaded
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
