//
//  SecondViewController.swift
//  Lab1
//
//  Created by Cassandra Goodby on 1/25/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    @IBAction func gotoorder(_ sender: UIButton) {
        if(UIApplication.shared.canOpenURL(URL(string: "grubhub://")!)){
            UIApplication.shared.open(URL(string: "grubhub://")!, options: [:], completionHandler: nil)
        }else{
            
            if(UIApplication.shared.canOpenURL(URL(string: "ubereats://")!)){
                UIApplication.shared.open(URL(string: "ubereats://")!, options: [:], completionHandler: nil)
            }else {
                UIApplication.shared.open(URL(string: "https://www.grubhub.com/lets-eat")!, options: [:], completionHandler: nil)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

