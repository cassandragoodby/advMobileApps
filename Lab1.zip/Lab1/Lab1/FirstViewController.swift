//
//  FirstViewController.swift
//  Lab1
//
//  Created by Cassandra Goodby on 1/25/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    @IBOutlet weak var restaurantPicker: UIPickerView!
    @IBOutlet weak var choiceLabel: UILabel!
    
    let restaurantComponent = 0
    let foodComponent = 1
    
    var foodplaces = [String: [String]]()
    var restaurant = [String]()
    var food = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let pathURL = Bundle.main.url(forResource: "foodplaces", withExtension: "plist"){
            let plistdecoder = PropertyListDecoder()
            do{
                let data = try Data(contentsOf: pathURL)
                foodplaces = try plistdecoder.decode([String: [String]].self, from: data)
                restaurant = Array(foodplaces.keys)
                food = foodplaces[restaurant[0]]! as [String]
            }
            catch{
                print(error)
            }
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == restaurantComponent{
            return restaurant.count
        }
        else{
            return food.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == restaurantComponent{
            return restaurant[row]
        }
        else{
            return food[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == restaurantComponent {
            let selectedRestaurant = restaurant[row]
            food = foodplaces[selectedRestaurant]!
            restaurantPicker.reloadComponent(foodComponent)
            restaurantPicker.selectRow(0, inComponent: foodComponent, animated: true)
        }

        let restaurantsRow = pickerView.selectedRow(inComponent: restaurantComponent)
        let foodsRow = pickerView.selectedRow(inComponent: foodComponent)
        choiceLabel.text="You like \(restaurant[restaurantsRow]) & \(food[foodsRow])"
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

