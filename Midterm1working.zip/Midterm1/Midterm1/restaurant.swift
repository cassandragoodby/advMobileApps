//
//  restaurant.swift
//  Midterm1
//
//  Created by Cassandra Goodby on 3/15/18.
//  Copyright © 2018 Cassandra Goodby. All rights reserved.
//

import Foundation


class Restaurant {
    var RestaurantName = [String]()
    var urls = [String]()
}

class restaurantA{
    var restaurantA = ["Luciles", "Rincon Argentina", "Backcountry Pizza","West End Tavern"]
    var urlA = ["https://www.luciles.com/","https://www.rinconargentinoboulder.com/","https://www.backcountrypizzaandtaphouse.com/","https://www.thewestendtavern.com/"]
}

struct restaurant: Decodable{
    let title: String
    let url : String
}
