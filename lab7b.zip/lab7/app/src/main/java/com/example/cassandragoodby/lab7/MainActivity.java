package com.example.cassandragoodby.lab7;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.XmlResourceParser;
import android.os.Bundle;
import android.view.View;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

public class MainActivity extends Activity implements typeListFragment.DrinksListListener, DrinksDetailFragment.ButtonClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(drinks.drinksName.isEmpty()) {
                loadDrinks(this);

//            try {
//                loadDrinks(this);
//                loadXML(this);
//            } catch (XmlPullParserException e) {
//                e.printStackTrace();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
        }
    }

    private void loadXML(Activity activity) throws XmlPullParserException, IOException {
        String new_type = new String();
        ArrayList<String> new_drinks=new ArrayList<String>();
        StringBuffer stringBuffer = new StringBuffer();
        XmlResourceParser xpp = getResources().getXml(R.xml.drinks);
        xpp.next();
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            switch (eventType) {
                case XmlPullParser.START_DOCUMENT:
                    break;
                case XmlPullParser.START_TAG:
                    if (xpp.getName().equals("type")) {
                        stringBuffer.append("\nSTART_TAG: " + xpp.getName());
                    }
                    if (xpp.getName().equals("name")) {
                        stringBuffer.append("\nSTART_TAG: " + xpp.getName());
                        eventType = xpp.next();
                        new_type = xpp.getText();
                    } else if (xpp.getName().equals("drink")) {
                        stringBuffer.append("\nSTART_TAG: " + xpp.getName());
                        eventType = xpp.next();
                        new_drinks.add(xpp.getText());
                    }
                    break;
                case XmlPullParser.END_TAG:
                    if (xpp.getName().equals("type")) {
                        drinks new_drink = new drinks(new_type, new_drinks);
                        drinks.drinksName.add(new_drink);
                        new_type = "";
                        new_drinks.clear();
                    }
                    break;

                case XmlPullParser.TEXT:
                    break;
            }
            eventType = xpp.next();
        }
        System.out.println(stringBuffer.toString());
    }

    public void loadDrinks(Context context) {
        SharedPreferences sharedPrefs = context.getSharedPreferences("drinks", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPrefs.edit();
        Map<String, ?> alldata = sharedPrefs.getAll();
        if (alldata.size() > 0) {
            for (Map.Entry<String, ?> entry : alldata.entrySet()) {
                String newdrinks = (String) entry.getKey();
                ArrayList<String> drinklist = new ArrayList<String>();
                drinklist.addAll(sharedPrefs.getStringSet(newdrinks, null));
                drinks new_drink = new drinks(newdrinks, drinklist);
                drinks.drinksName.add(new_drink);
            }
        } else { //no data, load XML file
            try {
                loadXML(this);
            } catch (XmlPullParserException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override public void itemClicked(long id){
        View fragmentContainer = findViewById(R.id.fragment_container);
        if (fragmentContainer != null) {
            DrinksDetailFragment frag = new DrinksDetailFragment();
            frag.setType(id);

            FragmentTransaction ft = getFragmentManager().beginTransaction();
            ft.replace(R.id.fragment_container, frag);
            ft.addToBackStack(null);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            ft.commit();
        } else{
            Intent intent = new Intent(this, DetailActivity.class);
            intent.putExtra("id", (int) id);
            startActivity(intent);
        }
    }



    @Override public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0 ){
            getFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    @Override public void adddrinkclicked(View view){
        DrinksDetailFragment fragment =
                (DrinksDetailFragment)getFragmentManager().findFragmentById(R.id.fragment_container);
        fragment.adddrink();
    }


}
