package com.example.cassandragoodby.lab7;


import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class DrinksDetailFragment extends Fragment implements View.OnClickListener{

    private ArrayAdapter<String> adapter;

    private long typeId;

    public void setType(long id){
        this.typeId = id;
    }

    public DrinksDetailFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (savedInstanceState !=null){
            typeId = savedInstanceState.getLong("typeId");
        }
        return inflater.inflate(R.layout.fragment_drinks_detail, container, false);
    }

    @Override public void onStart(){
        super.onStart();
        View view = getView();
        ListView listDrinks = (ListView) view.findViewById(R.id.drinkslistView);
        ArrayList<String> drinkslist = new ArrayList<String>();
        drinkslist = drinks.drinksName.get((int) typeId).getDrinkKind();
//        drinkslist = drinks.drinksName[(int) typeId].getDrinkKind();
        adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, drinkslist);
        listDrinks.setAdapter(adapter);
        Button adddrinkbutton = (Button) view.findViewById(R.id.adddrinkbutton);
        adddrinkbutton.setOnClickListener(this);
        registerForContextMenu(listDrinks);
    }

    @Override public void onSaveInstanceState(Bundle savedInstanceState){
        savedInstanceState.putLong("typeId", typeId);
    }

    interface ButtonClickListener{
        void adddrinkclicked(View view);
    }

    private ButtonClickListener listener;
    @Override public void onAttach(Context context){
        super.onAttach(context);
        listener = (ButtonClickListener)context;
    }

    @Override public void onClick(View view){
        if (listener !=null){
            listener.adddrinkclicked(view);
        }
    }

    public void adddrink(){
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        final EditText edittext = new EditText(getActivity());
        dialog.setView(edittext);
        dialog.setTitle("Add Drink");
        dialog.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                String drinkName = edittext.getText().toString();
                if(!drinkName.isEmpty()){
                    drinks.drinksName.get((int) typeId).getDrinkKind().add(drinkName);
                    DrinksDetailFragment.this.adapter.notifyDataSetChanged();
                    drinks.drinksName.get((int) typeId).storeDrinks(getActivity(), typeId);
                }
            }
        });
        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        dialog.show();
    }

    @Override public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, view, menuInfo);
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        String drinkname = adapter.getItem(adapterContextMenuInfo.position);
        menu.setHeaderTitle("Delete " + drinkname);
        menu.add(1, 1, 1, "Yes");
        menu.add(2, 2, 2, "No");
    }

    @Override public boolean onContextItemSelected(MenuItem item){
        int itemId = item.getItemId();
        if (itemId == 1) {
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
//            drinks.drinksName[(int) typeId].getDrinkKind().remove(info.position);
            drinks.drinksName.get((int) typeId).getDrinkKind().remove(info.position);
            DrinksDetailFragment.this.adapter.notifyDataSetChanged();
            drinks.drinksName.get((int) typeId).storeDrinks(getActivity(), typeId);
        }
        return true;
    }
}
