package com.example.cassandragoodby.lab7;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by CassandraGoodby on 5/1/18.
 */

public class drinks {
    private String type;
    private ArrayList<String> kindofdrinks = new ArrayList<>();

//    private drinks(String drinkType, ArrayList<String>drinksName){
//        this.type = drinkType;
//        this.kindofdrinks = new ArrayList<String>(drinksName);
//    }

    public drinks(String drinkType, ArrayList<String> drinksName){
        this.type = drinkType;
        this.kindofdrinks = new ArrayList<String>(drinksName);
    }

//    public static final drinks[]drinksName ={
//            new drinks(("Tea"), new ArrayList<String>(Arrays.asList("Black Tea", "Green Tea", "Matcha Tea", "Lemon Tea", "Hibiscus Tea"))),
//            new drinks(("Coffee"), new ArrayList<String>(Arrays.asList("Latte", "Americano", "Cold Press", "Iced Coffee", "Cappuccino")))
//    };

    public static ArrayList<drinks> drinksName = new ArrayList<drinks>();

    public String getKind(){
        return type;
    }

    public ArrayList<String> getDrinkKind(){
        return kindofdrinks;
    }
    public String toString(){
        return this.type;
    }

    public void storeDrinks(Context context, long typeId){
        SharedPreferences sharedPrefs = context.getSharedPreferences("drinks", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPrefs.edit();
        Set<String> set = new HashSet<String>();
        set.addAll(drinksName.get((int) typeId).getDrinkKind());
        editor.putStringSet(drinksName.get((int) typeId).getKind(), set);
//        editor.putStringSet(drinksName.get((int) typeId).getKind(), set);
        editor.commit();
    }
}

