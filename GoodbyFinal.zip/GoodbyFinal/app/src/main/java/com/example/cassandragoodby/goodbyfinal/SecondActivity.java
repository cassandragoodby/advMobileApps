package com.example.cassandragoodby.goodbyfinal;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class SecondActivity extends Activity {
    private String workouttype;

    String[] workoutsList = new String[] {

    };

    ArrayList<String> workout_list = new ArrayList<String>(Arrays.asList(workoutsList));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //get reference to action bar
        ActionBar actionBar = getActionBar();
//enable the up button
        actionBar.setDisplayHomeAsUpEnabled(true);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Intent i = getIntent();
        workouttype = i.getStringExtra("workoutType");
        ListView listtype = (ListView) findViewById(R.id.listView2);
        ArrayAdapter<String> listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, workout_list);

//        ArrayAdapter<workouts> listAdapter;
//        switch (workouttype){
//            case "Cardio":
//                listAdapter = new ArrayAdapter<workouts>(this, android.R.layout.simple_list_item_1, workouts.cardio);
//                break;
//            case "Strength":
//                listAdapter = new ArrayAdapter<workouts>(this, android.R.layout.simple_list_item_1, workouts.strength);
//                break;
//            case "Flexibility":
//                listAdapter = new ArrayAdapter<workouts>(this, android.R.layout.simple_list_item_1, workouts.flexibility);
//                break;
//            default: listAdapter = new ArrayAdapter<workouts>(this, android.R.layout.simple_list_item_1, workouts.cardio);
//        }

//set the array adapter on the list view
        listtype.setAdapter(listAdapter);

        listtype.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int arg2, long arg3) {
                final int delete = arg2;
                AlertDialog.Builder alert = new AlertDialog.Builder(SecondActivity.this);
                alert.setTitle("Delete Entry");
                alert.setMessage("Are you sure you want to delete?");
                alert.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        workout_list.remove(delete);
                        onDataChange();
                    }
                });
                alert.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                alert.show();
                return false;
            }
        });

        Button addbutton = (Button)findViewById(R.id.button);
        addbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertadd = new AlertDialog.Builder(SecondActivity.this);
                alertadd.setTitle("Add Activity");

                final EditText input = new EditText(SecondActivity.this);

                input.setInputType(InputType.TYPE_CLASS_TEXT);
                alertadd.setView(input);

                alertadd.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
//                        dialog.cancel();
                        m_Text = input.getText().toString();
                        workout_list.add(m_Text);
//                        workouts[] flexibility = {
//                                new workouts(m_Text)
//                        };
                    }
                });

                alertadd.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                alertadd.show();

            }
        });
    }

    public void onDataChange(){
        ListView listtype = (ListView) findViewById(R.id.listView2);
        ArrayAdapter<String> listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, workout_list);
        listtype.setAdapter(listAdapter);
    }
    private String m_Text = "";

}
