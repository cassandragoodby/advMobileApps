package com.example.cassandragoodby.goodbyfinal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView list = (ListView)findViewById(R.id.listView);
        ArrayAdapter<workouts> listAdapter;
        listAdapter = new ArrayAdapter<workouts>(this, android.R.layout.simple_list_item_1, workouts.all);
        list.setAdapter(listAdapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
//                String song_name = (String) listView.getItemAtPosition(position);
                String workouttype =listView.getItemAtPosition(position).toString();
//                String workouttype = "cardio";
                intent.putExtra("workoutType", workouttype);
                startActivity(intent);
//                Toast.makeText(getAct,"Item Selected",Toast.LENGTH_LONG).show();
            }
        });
    }
}
