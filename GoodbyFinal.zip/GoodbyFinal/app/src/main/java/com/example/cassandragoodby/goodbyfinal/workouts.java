package com.example.cassandragoodby.goodbyfinal;

/**
 * Created by CassandraGoodby on 5/6/18.
 */

public class workouts {
    private String name;

    //constructor
    public workouts(String newname){
        this.name = newname;
    }
    public static final workouts[] all = {
            new workouts("Cardio"),
            new workouts("Strength"),
            new workouts("Flexibility")
    };

    public static final workouts[] cardio = {
            new workouts("Running")
    };

    public static final workouts[] strength = {
            new workouts("Lift")
    };

    public static final workouts[] flexibility = {
            new workouts("Stretch")
    };

    public String getName(){
        return name;
    }

    public String toString(){
        return this.name;
    }

}
