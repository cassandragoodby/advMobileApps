package com.example.cassandragoodby.lab9;

/**
 * Created by CassandraGoodby on 5/8/18.
 */

public class quoteItem {
    private String id;
    private String name;
    private String quote;
    public quoteItem(){

    }
    public quoteItem(String newid, String newName, String newquote){
        id = newid;
        name = newName;
        quote = newquote;
    }
    public String getId() {
        return id;
    }
    public String getName(){
        return name;
    }
    public String getquote(){
        return quote;
    }
    //the string representation of a recipe name
    public String toString(){
        return this.name;
    }
}
