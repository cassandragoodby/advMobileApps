package com.example.cassandragoodby.lab9;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference();
    DatabaseReference quoteRef = database.getReference("quote");
    List quotes = new ArrayList<>();
    ArrayAdapter<quoteItem> listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setImageResource(R.drawable.plus);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LinearLayout layout = new LinearLayout(MainActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);

                final EditText quoteEditText = new EditText(MainActivity.this);
                quoteEditText.setHint("Quote");
                layout.addView(quoteEditText);
                final EditText nameEditText = new EditText(MainActivity.this);
                nameEditText.setHint("Name");
                layout.addView(nameEditText);

                //ALERT DIALOG BOX

                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("Add Quote");
                dialog.setView(layout);
                dialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //get entered data
                        String quoteQuote = quoteEditText.getText().toString();
                        String quoteName = nameEditText.getText().toString();
                        if (quoteName.trim().length() > 0) {
                            //get new id from firebase
                            String key = quoteRef.push().getKey();
                            quoteItem newQuote = new quoteItem(key, quoteName, quoteQuote);
                            quoteRef.child(key).child("name").setValue(newQuote.getName());
                            quoteRef.child(key).child("quote").setValue(newQuote.getquote());
                        }
                    }
                });
                dialog.setNegativeButton("Cancel", null);
                dialog.show();

            }
        });


        //Initial View
        final ListView quoteList = (ListView) findViewById(R.id.listView);
        listAdapter = new ArrayAdapter<quoteItem>(this, android.R.layout.simple_expandable_list_item_1,quotes);
        quoteList.setAdapter(listAdapter);
        listAdapter.notifyDataSetChanged();

        //Adding data
        ValueEventListener firebaseListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                quotes.clear();
                for (DataSnapshot snapshot: dataSnapshot.getChildren()){
                    String newId = snapshot.getKey();
                    quoteItem QuoteItem = snapshot.getValue(quoteItem.class);
                    quoteItem newQuote = new quoteItem(newId,QuoteItem.getquote(),QuoteItem.getName());
                    quotes.add(newQuote);
                }
                listAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("oncreate","Failed to read", databaseError.toException());
//                Log.w("oncreate", "Failed to read value.", error.toException());
            }
        };

        quoteRef.addValueEventListener(firebaseListener);
        registerForContextMenu(quoteList);
    }

    @Override public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, view, menuInfo);
        //cast ContextMenu.ContextMenuInfo to AdapterView.AdapterContextMenuInfo since we're using an adapter
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        String quotename = ((TextView) adapterContextMenuInfo.targetView).getText().toString();
        menu.setHeaderTitle("Delete " + quotename);
        menu.add(1, 1, 1, "Yes");
        menu.add(2, 2, 2, "No");
    }

    @Override public boolean onContextItemSelected(MenuItem item){
        //get the id of the item
        int itemId = item.getItemId();
        if (itemId == 1) {
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            quoteItem selectedQuote = (quoteItem) quotes.get(info.position);
            String quoteid = selectedQuote.getId();
            quoteRef.child(quoteid).removeValue();
        }
        return true;
    }
}
